package com.cg.contoller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.entities.Student;
import com.cg.service.StudentService;

@Controller

public class StudentController {
	@Autowired
	private StudentService studentService;
	@RequestMapping(value = "/index.obj")
	public String showIndex(Model model) {
		return "index";
	}
	@RequestMapping(value = "showHomePage")
	public String showHomePage(Model model) {
		return "index";
	}
	@RequestMapping(value="/showAddStudent")
	public String getHomePage(Model model){
		model.addAttribute("stuList",studentService.showAll());
		model.addAttribute("stream",new String[]{"CSE","EEE","ME","CE"});
		model.addAttribute("student",new Student());
		return "addStudent";
	}

	@SuppressWarnings("unused")
	@RequestMapping(value="/save.obj",method=RequestMethod.POST)
	public String addStudent(@Valid @ModelAttribute("student") Student student,BindingResult result, Model model){
		int studentId=0;
		if (result.hasErrors()) {
			return "addStudent";
		}
		
		try
		{
			student =  studentService.addStudent(student);
		   model.addAttribute("message","Student with id "+student.getStudentId()+" added successfully!");
		}
		catch(DataAccessException dataAccessException)
		{
			model.addAttribute("msg","Technical Problem..Please Try Later!!");
			return "myError";
		}
		if (student != null) {
			model.addAttribute("studentId", studentId);
			model.addAttribute("fName", student.getFirstName());
			
			return "addSuccess";
		} 
		else 
		{
			String msg = "Technical Problem..Please Try Later!!";
			model.addAttribute("msg", msg);
			return "myError";
		}
	}
		
	@RequestMapping("/listall.obj")
	public String getStudentDetails(Model model){

		try
		{
			List<Student> list = studentService.showAll();
			if (list.isEmpty()) {
				String msg = "There are no Students";
				model.addAttribute("msg", msg);
				return "myError";
			}
			// Add the attribute to the model
			model.addAttribute("stuList", list);
			return "listOfStudents";
		}
		catch(DataAccessException dataAccessException)
		{
			model.addAttribute("msg","Technical Problem..Please Try Later!!");
			return "myError";
		}

	}

		
}

